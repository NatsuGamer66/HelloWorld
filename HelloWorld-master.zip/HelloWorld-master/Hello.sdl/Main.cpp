#include "SDL/include/SDL.h"
#pragma comment( lib, "SDL/libx86/SDL2.lib" )
#pragma comment( lib, "SDL/libx86/SDL2main.lib" )
#include <iostream>

int main(int argc, char** argv)
{
	std::cout << "Have " << argc << " arguments:" << std::endl;

	for (int i = 0; i < argc; ++i) 
	{
		std::cout << argv[i] << std::endl;
	}

	return 0;
}